import firebase from "firebase";

export const firebaseConfig = {
  apiKey: "AIzaSyArr8Ipyd-antbmGz8ZqmOL2bpokxlAGrg",
  authDomain: "in-good-hands-784be.firebaseapp.com",
  databaseURL: "https://in-good-hands-784be.firebaseio.com",
  projectId: "in-good-hands-784be",
  storageBucket: "in-good-hands-784be.appspot.com",
  messagingSenderId: "413077349268",
  appId: "1:413077349268:web:ac7b7679589d1ea7e8a581",
  measurementId: "G-298LGBWCB8"
};

export default firebase;
