export default {
  first: 'Fundation',
  second: 'Organization',
  third: 'Company',
};
