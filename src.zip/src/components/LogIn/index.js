import React from "react";

const LogIn = () => {
  return (
    <div>
      test
    </div>
  )
};

export default LogIn;
