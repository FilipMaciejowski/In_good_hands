import React from 'react';
import { Link } from 'react-router-dom';

const Step = ( {children , topic, description} ) => {
  
  return (
    <div className="step__element">
      <Link to="/login">
        <div>{children}</div>
        <h1>{topic}></h1>
        <svg height="210" width="500">
          <line
            x2="50"
            style={{stroke:'#000', strokeWidth:'4'}}
          />
        </svg>
        <p>{description}</p>
      </Link>
    </div>
  );
};

export default Step;