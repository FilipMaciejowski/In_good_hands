import React from 'react';

const HomeAboutUs = () => {
  return (
    <div>home about us</div>
  )
};

export default HomeAboutUs;