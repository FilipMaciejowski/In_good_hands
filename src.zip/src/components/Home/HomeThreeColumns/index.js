import React from 'react';

const HomeThreeColumns= () => {
  return (
    <div>three columns</div>
  )
};

export default HomeThreeColumns;

