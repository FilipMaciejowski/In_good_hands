import React from 'react';

const HomeFourSteps = () =>{
  return (
    <div>four steps</div>
  )
};


export default HomeFourSteps;

