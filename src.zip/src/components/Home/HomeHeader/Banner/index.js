import React from 'react';
import { Link } from 'react-scroll';

const Banner = () =>{
  return (
    <div className="home__header-banner">
      <div className="home__header-banner-content">
        <h1>
          Let´s help!
          <br />
          Give away unused items
        </h1>
        <Link>Donate</Link>
        <Link>Organize donation</Link>
      </div>
    </div>
  );
};

export default Banner;
