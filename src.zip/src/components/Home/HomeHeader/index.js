import React, {useEffect, useState} from 'react';
import { NavLink } from 'react-router-dom';
import { Link } from 'react-scroll';
import { useSelector } from "react-redux";
import { logOutUser } from "../../../firebase/firebase-actions/authentication";
import Banner from '../HomeHeader/Banner';

const HomeHeader = () => {
  const userData = useSelector(state => state.userData);
  const [userState, setUserState] = useState(false);
  useEffect(() => {
    setUserState(userData.logged)
    console.log(userData)
  },[userData]);

  return (
    <div className="home__header-container">
      <div className="home__header-right-side">
        <div className="right__side-top-nav">
          {userState
            ?
            <div>
              <p>Hi {userData.user.userName}</p>
              <button onClick={() => logOutUser()}>Log out</button>
            </div>
            :
            <div>
              <NavLink to="/registration/login">Log inn</NavLink>
              <NavLink to="/registration/signup">Sign up</NavLink>
            </div>
        }
        </div>
        <div className="right__side-bottom-nav">
          <Link>Start</Link>
          <Link>Idea</Link>
          <Link>About us</Link>
          <Link>Foundation and Organizations</Link>
          <Link>Contact</Link>
        </div>
        <Banner />
      </div>

      <div className="home__header-left-side">
        <img
          src={require('../../../assets/images/HOME-HERO-IMAGE.jpeg')}
          alt="unused items header"
        />
      </div>
    </div>
  );
};

export default HomeHeader;
