import React from 'react';

const HomeFooter = () =>{
  return (
    <div>footer</div>
  )
};

export default HomeFooter;


