import React from 'react';

const HomeContact = () => {
  return (
    <div>contact</div>
  )
};

export default HomeContact;
