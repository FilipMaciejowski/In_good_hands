import React from 'react';

const HomeWeHelp = () => {
  return (
    <div>we help</div>
  )
};

export default HomeWeHelp;

