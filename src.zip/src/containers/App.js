import React from "react";
import Home from "../components/Home";
import {
  HashRouter as Router,
  Switch,
  Route,
  Redirect
} from "react-router-dom";
import Registration from '../components/Registration';
import firebase from "firebase";
import { firebaseConfig } from "../firebase/firestore";
import { store } from "../redux";
import { Provider } from "react-redux";
import { checkIsUserLogged } from "../firebase/firebase-actions/authentication"

const App = () => {
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  firebase.auth().onAuthStateChanged(user => checkIsUserLogged(user));
  return (
    <Provider store={store}>
      <div className="App">
        <Router>
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/registration" component={Registration}/>
            <Redirect path="*" to="/" />
          </Switch>
        </Router>
      </div>
    </Provider>
  );
};

export default App;
